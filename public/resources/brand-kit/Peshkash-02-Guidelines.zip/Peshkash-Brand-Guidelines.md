# Peshkash brand guidelines

## Brand idea

Peshkash means an offering. The identity combines a bookmark, folded paper and a scan frame: something worth keeping, intentionally presented and digitally discoverable.

## Logo anatomy

- The bookmark stem supplies the capital P.
- The solid D-shaped shoulder contains exactly three origami planes and two crease boundaries.
- The handwritten vector artwork reads `eshkash`; together the mark reads Peshkash once.
- Four scan corners frame the P and first e. The remaining letters spill outward.

## Core palette

| Colour | Hex | Role |
|---|---:|---|
| Near-black | `#1A1410` | Dark backgrounds and primary text |
| Cream | `#F5F2EE` | Preferred light background |
| Brand gold | `#BD945A` | Product UI and calls to action |
| Logo brass | `#BB9057` | Bookmark and scan corners |
| Bone | `#E8DBCE` | Upper origami plane |
| Stone beige | `#C5AF9D` | Outer origami plane |
| Mushroom taupe | `#8C7667` | Lower return plane |
| Muted text | `#564C40` | Secondary copy |

## Clear space and minimum sizes

- Clear space: at least one bookmark-stem width on every side.
- Primary lockup: minimum 180 px digital or 38 mm print.
- Framed symbol: minimum 48 px digital or 12 mm print.
- The official text-free logo always includes the four L-corner scan frame.
- For 16-32 px use only the supplied optimized favicon/app-icon exports.

## Background use

- Use `Primary-For-Light` on cream or white.
- Use `Primary-For-Dark` on near-black or other sufficiently dark solids.
- Use monochrome variants only when production limits prevent the full-colour mark.
- Avoid photography or textured surfaces that reduce the fold separation or wordmark contrast.

## Never

- Add or remove origami folds.
- Create a hollow counter inside the P.
- Use the P alone as a text-free logo; retain the four scan corners.
- Replace the custom lettering with a font.
- Symmetrise or redraw the scan corners.
- Stretch, rotate, outline, emboss or add glow.
- Recolour individual planes outside the supplied palette.

## Typography

- Rufina for display and campaign headlines.
- Urbanist for body copy and UI.
- Custom outlined artwork for the logo only.

## Voice

Direct, warm and confident. Speak like a smart local business owner, not a software company.

Approved examples:
- “Your shop window just became the internet.”
- “If you’re not scannable, you’re invisible.”
- “A QR is the cheapest marketing you’ll ever buy.”
