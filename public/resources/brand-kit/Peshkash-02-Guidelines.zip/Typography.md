# Peshkash typography

## Display - Rufina

Use for major headlines, campaign statements and editorial moments. Recommended weights: 400 and 700.

## Body and UI - Urbanist

Use for body copy, labels, navigation and product UI. Recommended weights: 400, 500, 600 and 700.

## Wordmark - custom outlined artwork

The approved `eshkash` lettering is included as vector paths inside every primary SVG. Never retype, substitute or rebuild it with a font.

Google Fonts sources:
- https://fonts.google.com/specimen/Rufina
- https://fonts.google.com/specimen/Urbanist
