# Logo export matrix

## Vector masters

Use the SVG files for print, signage, fabrication, large-format output and any editable production workflow. SVG artwork is resolution-independent.

## Primary lockup PNGs

- 2000 px wide: presentations, documents and standard digital use
- 4000 px wide: high-density screens, print mockups and large digital placements
- 8000 px wide: maximum-resolution raster handoff and large-format mockups

## Framed symbol PNGs

- 512 px: standard profile and interface use
- 1024 px: high-density social and product use
- 2048 px: large digital and print mockups
- 4096 px: maximum-resolution raster handoff

## App and favicon exports

Optimized framed-symbol icons are supplied from 16 px through 4096 px. Use the exact requested platform size; do not downscale the primary logo manually.

Browser favicon assets use the dedicated transparent `Peshkash-Favicon` master. The PNG aliases and multi-resolution ICO preserve alpha at their outer corners. The `Peshkash-App-Icon-Light` and `Peshkash-App-Icon-Dark` families intentionally retain solid platform backgrounds and must not be substituted for the transparent browser favicon.

`Icons/favicon.svg` is the exact lowercase, transparent deployment alias intended for a root reference such as `/favicon.svg`.

## Non-negotiable symbol rule

Whenever the wordmark is absent, retain the four L-corner scan frame. The origami P alone is not an official logo configuration.
