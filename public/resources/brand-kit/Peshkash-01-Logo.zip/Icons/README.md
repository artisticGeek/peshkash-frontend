# Peshkash icon assets

## Transparent browser favicon family

Use these files for browser and web-manifest favicon references:

- `Peshkash-Favicon.svg` — transparent vector master
- `favicon.svg` — identical lowercase deployment alias for manifests that request `/favicon.svg`
- `Peshkash-Favicon-16.png`, `-32.png`, `-48.png`, `-180.png`, `-192.png`, `-512.png` — transparent raster exports
- `favicon-16x16.png` and `favicon-32x32.png` — standard transparent aliases
- `Peshkash-Favicon.ico` — transparent multi-resolution ICO
- `favicon.ico` — identical lowercase web-root fallback
- `apple-touch-icon.png`, `android-chrome-192x192.png`, `android-chrome-512x512.png` — transparent web-manifest aliases requested for this handoff

The framed origami P is preserved; only the surrounding canvas is transparent.

## Solid app-icon family

`Peshkash-App-Icon-Light-*` and `Peshkash-App-Icon-dark-*` are composed app tiles with cream or near-black backgrounds. Keep them for app stores, launchers, mockups or platforms that require a solid tile. They are not the browser favicon source.

## Deployment

Replace this entire folder to keep all aliases synchronized.

For Vite, React or similar setups that serve the `public` directory at the site root:

```text
copy Brand kit/01 Logo/Icons/favicon.svg
to   <website project>/public/favicon.svg
```

Then these references resolve correctly:

```html
<link rel="icon" href="/favicon.svg" type="image/svg+xml">
<link rel="icon" href="/favicon-32x32.png" sizes="32x32" type="image/png">
```

```json
{
  "icons": [
    { "src": "/favicon.svg", "sizes": "any", "type": "image/svg+xml", "purpose": "any" },
    { "src": "/android-chrome-192x192.png", "sizes": "192x192", "type": "image/png", "purpose": "any" },
    { "src": "/android-chrome-512x512.png", "sizes": "512x512", "type": "image/png", "purpose": "any" }
  ]
}
```

Verification: open `/favicon.svg` directly in the browser or check the Network panel. It must return HTTP 200 with SVG content. A DevTools message saying the icon “failed to load” means the file is missing from the served public root; it is not a transparency or browser-rendering issue.
